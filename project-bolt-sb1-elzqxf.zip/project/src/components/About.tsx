import React from 'react';
import { Building2, Sun } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#2B4D3A] mb-4">À Propos de Nous</h2>
          <p className="text-xl text-gray-600">Bureau d'étude spécialisé en économie d'Énergie et photovoltaïque</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80"
              alt="Installation Photovoltaïque"
              className="rounded-lg shadow-xl"
            />
          </div>
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="bg-[#90EE90] p-3 rounded-full">
                <Building2 className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Expertise Technique</h3>
                <p className="text-gray-600">
                  Notre bureau d'études combine expertise technique et engagement environnemental pour vous offrir des solutions sur mesure.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-[#90EE90] p-3 rounded-full">
                <Sun className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Solutions Durables</h3>
                <p className="text-gray-600">
                  Nous concevons des hangars photovoltaïques qui allient fonctionnalité et production d'énergie renouvelable.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}