import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#2B4D3A] mb-4">Contactez-nous</h2>
          <p className="text-xl text-gray-600">Discutons de votre projet</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="flex items-center space-x-4">
              <div className="bg-[#90EE90] p-3 rounded-full">
                <MapPin className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Adresse</h3>
                <p className="text-gray-600">8 rue de la convention, 69100 VILLEURBANNE</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="bg-[#90EE90] p-3 rounded-full">
                <Phone className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Téléphone</h3>
                <a href="tel:0663932444" className="text-gray-600 hover:text-[#2B4D3A]">06 63 93 24 44</a>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="bg-[#90EE90] p-3 rounded-full">
                <Mail className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Email</h3>
                <a href="mailto:bureaudetudebf26@gmail.com" className="text-gray-600 hover:text-[#2B4D3A]">
                  bureaudetudebf26@gmail.com
                </a>
              </div>
            </div>
          </div>

          <form className="space-y-6 bg-white p-8 rounded-lg shadow-lg">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nom</label>
              <input
                type="text"
                id="name"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                id="email"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <textarea
                id="message"
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full bg-[#2B4D3A] text-white py-3 px-6 rounded-md hover:bg-[#1A332B] transition-colors"
            >
              Envoyer
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}