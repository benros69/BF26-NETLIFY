import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="pt-20 min-h-screen bg-gradient-to-b from-[#2B4D3A] to-[#1A332B] text-white">
      <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h1 className="text-5xl font-bold mb-6">
            Optimisez Votre Espace avec l'Énergie Solaire
          </h1>
          <p className="text-xl mb-8 text-gray-200">
            Des structures innovantes pour un avenir durable et efficace
          </p>
          <a
            href="#contact"
            className="inline-flex items-center space-x-2 bg-[#90EE90] text-[#1A332B] px-6 py-3 rounded-full text-lg font-semibold hover:bg-white transition-colors"
          >
            <span>Demandez une Étude Gratuite</span>
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>
        <div className="relative">
          <img
            src="https://images.unsplash.com/photo-1613665813446-82a78c468a1d?auto=format&fit=crop&q=80"
            alt="Hangar Photovoltaïque"
            className="rounded-lg shadow-2xl"
          />
        </div>
      </div>
    </div>
  );
}