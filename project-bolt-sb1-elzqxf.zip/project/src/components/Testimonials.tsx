import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const testimonials = [
  {
    name: "Jean D.",
    role: "Agriculteur",
    text: "BF26 a transformé mon exploitation avec leur hangar photovoltaïque. La production d'énergie couvre largement mes besoins et génère un revenu supplémentaire."
  },
  {
    name: "Marie L.",
    role: "Chef d'entreprise",
    text: "L'équipe de BF26 a été professionnelle du début à la fin. Leur expertise technique et leur accompagnement ont été précieux pour notre projet d'installation solaire."
  },
  {
    name: "Pierre M.",
    role: "Industriel",
    text: "Excellent retour sur investissement avec notre hangar photovoltaïque. BF26 a su répondre parfaitement à nos besoins spécifiques."
  }
];

export default function Testimonials() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-[#2B4D3A] mb-12">
          Ce que disent nos clients
        </h2>
        <div ref={ref} className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="bg-white p-6 rounded-lg shadow-lg"
            >
              <p className="text-gray-600 mb-4">{testimonial.text}</p>
              <div className="border-t pt-4">
                <p className="font-semibold text-[#2B4D3A]">{testimonial.name}</p>
                <p className="text-sm text-gray-500">{testimonial.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}