import React from 'react';
import { PopupButton } from '@typeform/embed-react';

export default function ProjectForm() {
  return (
    <div className="w-full">
      <PopupButton
        id="gRY5DeMb"
        className="w-full bg-[#90EE90] text-[#1A332B] px-6 py-3 rounded-full text-lg font-semibold hover:bg-white transition-colors flex items-center justify-center space-x-2"
      >
        <span>Étudier mon projet gratuitement</span>
      </PopupButton>
    </div>
  );
}