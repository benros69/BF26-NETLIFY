import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

export default function SolarPanel({ position = [0, 0, 0], rotation = [0, 0, 0] }) {
  const meshRef = useRef();
  
  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(time * 0.5) * 0.2;
      meshRef.current.position.y = Math.sin(time * 0.5) * 0.1;
    }
  });

  return (
    <mesh
      ref={meshRef}
      position={position}
      rotation={rotation}
      castShadow
      receiveShadow
    >
      <boxGeometry args={[2, 0.1, 1]} />
      <meshStandardMaterial
        color="#2B4D3A"
        metalness={0.8}
        roughness={0.2}
        envMapIntensity={1}
      />
      <mesh position={[0, 0.1, 0]}>
        <boxGeometry args={[1.8, 0.05, 0.9]} />
        <meshStandardMaterial
          color="#1a1a1a"
          metalness={0.9}
          roughness={0.1}
          envMapIntensity={1}
        />
      </mesh>
    </mesh>
  );
}