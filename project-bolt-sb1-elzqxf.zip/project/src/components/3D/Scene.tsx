import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import SolarPanel from './SolarPanel';

export default function Scene() {
  return (
    <div className="h-[400px] w-full">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[5, 5, 5]} />
        <Suspense fallback={null}>
          <Environment preset="sunset" />
          <ambientLight intensity={0.5} />
          <directionalLight
            position={[10, 10, 5]}
            intensity={1}
            castShadow
            shadow-mapSize-width={1024}
            shadow-mapSize-height={1024}
          />
          <group position={[0, -1, 0]}>
            <SolarPanel position={[0, 0, 0]} rotation={[-0.2, 0, 0]} />
            <SolarPanel position={[2.5, 0, 0]} rotation={[-0.2, 0, 0]} />
            <SolarPanel position={[-2.5, 0, 0]} rotation={[-0.2, 0, 0]} />
          </group>
          <mesh
            rotation={[-Math.PI / 2, 0, 0]}
            position={[0, -1.5, 0]}
            receiveShadow
          >
            <planeGeometry args={[20, 20]} />
            <meshStandardMaterial color="#90EE90" />
          </mesh>
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 2}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}