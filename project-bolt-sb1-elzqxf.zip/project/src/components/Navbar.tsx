import React from 'react';
import { Sun, Phone } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function Navbar() {
  const location = useLocation();

  const links = [
    { path: '/', label: 'Accueil' },
    { path: '/about', label: 'À propos de nous' },
    { path: '/projects', label: 'Projets réalisés' },
    { path: '/faq', label: 'FAQ' },
    { path: '/contact', label: 'Contact' }
  ];

  return (
    <nav className="bg-[#2B4D3A] text-white py-4 px-6 fixed w-full z-50">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Sun className="w-8 h-8 text-[#90EE90]" />
          </motion.div>
          <span className="text-2xl font-bold">BF26</span>
        </Link>
        
        <div className="hidden md:flex space-x-8">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`relative hover:text-[#90EE90] transition-colors ${
                location.pathname === link.path ? 'text-[#90EE90]' : ''
              }`}
            >
              {link.label}
              {location.pathname === link.path && (
                <motion.div
                  layoutId="underline"
                  className="absolute left-0 right-0 h-0.5 bg-[#90EE90]"
                  animate={{ width: '100%' }}
                />
              )}
            </Link>
          ))}
        </div>

        <a 
          href="tel:0663932444" 
          className="flex items-center space-x-2 bg-[#1A332B] px-4 py-2 rounded-full hover:bg-[#90EE90] transition-colors"
        >
          <Phone className="w-4 h-4" />
          <span>06 63 93 24 44</span>
        </a>
      </div>
    </nav>
  );
}