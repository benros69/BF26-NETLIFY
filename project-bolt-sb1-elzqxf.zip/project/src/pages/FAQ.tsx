import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: "Quel est le coût d'installation d'un hangar photovoltaïque ?",
    answer: "Le coût varie en fonction de plusieurs facteurs : la taille du hangar, la puissance installée, les spécificités du terrain, etc. Nous réalisons une étude gratuite pour vous fournir un devis précis adapté à votre projet."
  },
  {
    question: "Combien de temps dure l'installation ?",
    answer: "La durée d'installation dépend de la taille du projet. En moyenne, un projet standard prend entre 2 et 4 mois, de l'étude initiale à la mise en service."
  },
  {
    question: "Quelles sont les démarches administratives nécessaires ?",
    answer: "Nous nous occupons de toutes les démarches administratives : permis de construire, raccordement au réseau, contrat d'achat d'électricité. Notre équipe vous accompagne à chaque étape."
  },
  {
    question: "Quelle est la durée de vie d'une installation photovoltaïque ?",
    answer: "Les panneaux photovoltaïques ont une durée de vie de 25 à 30 ans avec une garantie de production. La structure du hangar est conçue pour durer plusieurs décennies."
  },
  {
    question: "Comment est assurée la maintenance ?",
    answer: "Nous proposons des contrats de maintenance préventive et curative pour garantir la performance optimale de votre installation sur le long terme."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  return (
    <div className="pt-24">
      <div className="max-w-3xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-[#2B4D3A] mb-6">Questions Fréquentes</h1>
          <p className="text-xl text-gray-600">
            Retrouvez les réponses aux questions les plus courantes sur nos hangars photovoltaïques.
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="border border-gray-200 rounded-lg"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className="text-lg font-semibold text-[#2B4D3A]">{faq.question}</span>
                {openIndex === index ? (
                  <Minus className="w-5 h-5 text-[#2B4D3A]" />
                ) : (
                  <Plus className="w-5 h-5 text-[#2B4D3A]" />
                )}
              </button>
              <motion.div
                initial={false}
                animate={{ height: openIndex === index ? 'auto' : 0 }}
                className="overflow-hidden"
              >
                <p className="p-6 pt-0 text-gray-600">{faq.answer}</p>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}