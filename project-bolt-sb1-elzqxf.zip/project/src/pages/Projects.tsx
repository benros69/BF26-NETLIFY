import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const projects = [
  {
    title: "Hangar Agricole Solaire",
    location: "Rhône-Alpes",
    surface: "1200m²",
    production: "160 kWc",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80",
    description: "Installation d'un hangar photovoltaïque pour une exploitation agricole, permettant le stockage de matériel et la production d'énergie verte."
  },
  {
    title: "Centre Logistique Éco-responsable",
    location: "Auvergne",
    surface: "2500m²",
    production: "350 kWc",
    image: "https://images.unsplash.com/photo-1613665813446-82a78c468a1d?auto=format&fit=crop&q=80",
    description: "Conception et réalisation d'un centre logistique intégrant une toiture photovoltaïque complète."
  },
  {
    title: "Hangar Industriel Nouvelle Génération",
    location: "Loire",
    surface: "1800m²",
    production: "250 kWc",
    image: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?auto=format&fit=crop&q=80",
    description: "Structure moderne combinant espace de stockage et production d'énergie solaire pour une entreprise industrielle."
  }
];

export default function Projects() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-[#2B4D3A] mb-6">Nos Projets Réalisés</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez quelques-unes de nos réalisations qui illustrent notre expertise dans la conception et l'installation de hangars photovoltaïques.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 mb-20">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-white rounded-lg shadow-xl overflow-hidden"
            >
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-bold text-[#2B4D3A] mb-2">{project.title}</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-500">Localisation</p>
                    <p className="font-semibold">{project.location}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Surface</p>
                    <p className="font-semibold">{project.surface}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Production</p>
                    <p className="font-semibold">{project.production}</p>
                  </div>
                </div>
                <p className="text-gray-600 mb-6">{project.description}</p>
                <button className="flex items-center space-x-2 text-[#2B4D3A] font-semibold hover:text-[#90EE90] transition-colors">
                  <span>En savoir plus</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}