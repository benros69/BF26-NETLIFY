import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import ProjectForm from '../components/ProjectForm';
import Testimonials from '../components/Testimonials';
import Scene from '../components/3D/Scene';
import AnimatedSun from '../components/AnimatedSun';

export default function Home() {
  return (
    <div className="pt-20">
      <section className="min-h-screen bg-gradient-to-b from-[#2B4D3A] to-[#1A332B] text-white relative overflow-hidden">
        <div className="absolute top-20 right-20">
          <AnimatedSun />
        </div>

        <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold mb-6">
              Optimisez Votre Espace avec l'Énergie Solaire
            </h1>
            <p className="text-xl mb-8 text-gray-200">
              Spécialistes des hangars photovoltaïques, nous transformons vos espaces en sources d'énergie renouvelable. Notre expertise technique et notre engagement environnemental vous garantissent des solutions durables et rentables.
            </p>
            <ProjectForm />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <Scene />
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-[#2B4D3A] mb-12">
            Pourquoi choisir BF26 ?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Expertise Technique",
                description: "Notre bureau d'études possède une expertise pointue dans la conception et la réalisation de hangars photovoltaïques.",
                delay: 0
              },
              {
                title: "Solutions Sur Mesure",
                description: "Chaque projet est unique. Nous adaptons nos solutions à vos besoins spécifiques et aux contraintes de votre site.",
                delay: 0.2
              },
              {
                title: "Accompagnement Complet",
                description: "De l'étude initiale à la mise en service, nous vous accompagnons à chaque étape de votre projet.",
                delay: 0.4
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: item.delay }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
                className="p-6 bg-gray-50 rounded-lg shadow-lg"
              >
                <h3 className="text-xl font-semibold mb-4">{item.title}</h3>
                <p>{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Testimonials />
    </div>
  );
}