import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import ProjectForm from '../components/ProjectForm';

export default function Contact() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-[#2B4D3A] mb-6">Contactez-nous</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Notre équipe est à votre disposition pour étudier votre projet et répondre à toutes vos questions.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-2xl font-bold text-[#2B4D3A] mb-6">Nos Coordonnées</h2>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-[#90EE90] p-3 rounded-full">
                    <MapPin className="w-6 h-6 text-[#2B4D3A]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Adresse</h3>
                    <p className="text-gray-600">8 rue de la convention, 69100 VILLEURBANNE</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-[#90EE90] p-3 rounded-full">
                    <Phone className="w-6 h-6 text-[#2B4D3A]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Téléphone</h3>
                    <a href="tel:0663932444" className="text-gray-600 hover:text-[#2B4D3A]">
                      06 63 93 24 44
                    </a>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-[#90EE90] p-3 rounded-full">
                    <Mail className="w-6 h-6 text-[#2B4D3A]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Email</h3>
                    <a href="mailto:bureaudetudebf26@gmail.com" className="text-gray-600 hover:text-[#2B4D3A]">
                      bureaudetudebf26@gmail.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#2B4D3A] mb-6">Étudier Votre Projet</h2>
              <p className="text-gray-600 mb-6">
                Vous souhaitez obtenir une étude gratuite pour votre projet de hangar photovoltaïque ? Remplissez notre formulaire en ligne :
              </p>
              <ProjectForm />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <form className="bg-white p-8 rounded-lg shadow-xl">
              <div className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nom complet
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Téléphone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#90EE90] focus:border-transparent"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#2B4D3A] text-white py-3 px-6 rounded-md hover:bg-[#1A332B] transition-colors flex items-center justify-center space-x-2"
                >
                  <span>Envoyer le message</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}