import React from 'react';
import { motion } from 'framer-motion';
import { Sun, Users, Award, Leaf } from 'lucide-react';

export default function About() {
  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-[#2B4D3A] mb-6">À Propos de BF26</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Bureau d'étude spécialisé en économie d'Énergie et photovoltaïque, nous accompagnons nos clients dans leur transition énergétique depuis notre création.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <img
              src="https://images.unsplash.com/photo-1591696205602-2f950c417cb9?auto=format&fit=crop&q=80"
              alt="Notre équipe"
              className="rounded-lg shadow-xl"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-6"
          >
            <h2 className="text-3xl font-bold text-[#2B4D3A]">Notre Histoire</h2>
            <p className="text-gray-600">
              Fondée avec la vision d'accélérer la transition énergétique, BF26 s'est rapidement imposée comme un acteur majeur dans le secteur des hangars photovoltaïques. Notre expertise technique, combinée à notre engagement environnemental, nous permet de proposer des solutions innovantes et durables.
            </p>
            <p className="text-gray-600">
              Basés à Villeurbanne, nous intervenons dans toute la région pour transformer les espaces agricoles et industriels en véritables centrales de production d'énergie renouvelable.
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {[
            {
              icon: Users,
              title: "Expertise",
              description: "Une équipe d'experts passionnés par les énergies renouvelables"
            },
            {
              icon: Award,
              title: "Qualité",
              description: "Des solutions certifiées répondant aux plus hauts standards"
            },
            {
              icon: Leaf,
              title: "Engagement",
              description: "Un impact positif sur l'environnement et votre rentabilité"
            }
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-white p-6 rounded-lg shadow-lg"
            >
              <div className="bg-[#90EE90] w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <item.icon className="w-6 h-6 text-[#2B4D3A]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-[#2B4D3A] text-white p-12 rounded-lg text-center mb-20"
        >
          <h2 className="text-3xl font-bold mb-6">Notre Mission</h2>
          <p className="text-xl">
            Accompagner nos clients vers l'autonomie énergétique tout en créant de la valeur ajoutée pour leur activité.
          </p>
        </motion.div>
      </div>
    </div>
  );
}